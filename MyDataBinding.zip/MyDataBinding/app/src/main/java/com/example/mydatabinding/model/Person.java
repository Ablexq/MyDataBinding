package com.example.mydatabinding.model;

/*
 * plain-old Java Object（POJO）
 * */
public class Person {

    public String name;
    public int age;

    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }
}
