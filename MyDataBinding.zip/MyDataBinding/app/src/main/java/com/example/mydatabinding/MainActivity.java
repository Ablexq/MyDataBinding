package com.example.mydatabinding;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo1);

//        ActivityMainBinding binding = DataBindingUtil.setContentView(this, R.layout.activity_demo1);
//        binding.setUser(new User("xq", "666"));
//        binding.setPerson(new Person("xq2", 16));
    }
}
